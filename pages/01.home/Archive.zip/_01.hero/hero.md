---
title: Lalala
media_order: hero-bg.jpg
visible: true
heroTitle: 'Big Title Over Hero'
heroSubtitle: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
sitemap:
    changefreq: ''
    priority: ''
---

<span>the best medical center</span>
<h3><span>Bringing health</span><br />to life for the whole family.</h3>