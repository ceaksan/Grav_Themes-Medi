---
title: Home
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _hero
            - _welcome
            - _departments
            - _doctors
            - _steps
            - _contact
footer:
    element:
        name: Jobs
        link: /jobs
    text:
        description: null
        social:
            facebook: 'https://facebook.com'
            twitter: 'https://twitter.com'
            instagram: 'https://instagram.com'
            linkedin: 'https://linkedin.com'
    hours:
        monday-friday: '08.00 - 18.00'
        saturday: '08.00 - 18.00'
        sunday: '08.00 - 13.00'
---

